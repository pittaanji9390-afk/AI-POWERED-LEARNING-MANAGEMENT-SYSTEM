# Enterprise SaaS LMS & AI Platform — Comprehensive Threat Model (STRIDE)

## 1. Executive Summary & Scope
This threat model assesses security risks, attack surfaces, threat vectors, and mitigations for the Enterprise SaaS AI-Powered Learning Management System across all user tiers (Students, Instructors, Organization Admins, Platform Admins, and AI Automated Systems).

---

## 2. STRIDE Threat Analysis Matrix

### 2.1 Spoofing Identity
| Threat Vector | Risk Level | Attack Surface | Mitigation Controls | Verification Test |
| :--- | :--- | :--- | :--- | :--- |
| **JWT Signature Forgery** | Critical | REST API Authentication | HMAC-SHA256 with 256-bit rotating keys, short-lived tokens (15m), strict algorithm validation (`none` algorithm blocked). | `JwtTokenProviderTest#shouldRejectForgedSignature` |
| **Session Hijacking & Token Replay** | High | Refresh Token Lifecycle | Refresh Token Rotation (RTR), revocation list stored in Redis with TTL matching token validity. | `SessionSecurityIntegrationTest` |
| **Credential Stuffing / Brute Force** | High | `/api/v1/auth/login` | Token Bucket rate limiter (120 req/min per IP, 5 failed attempts per user per 15 min triggers lock). | `RateLimitSecurityTest` |
| **MFA Bypass** | High | Second Factor Challenge | Time-based One-Time Passwords (TOTP RFC 6238) with window drift check +-1 step; single-use recovery codes. | `MfaServiceTest#shouldRejectReusedTotp` |

### 2.2 Tampering with Data
| Threat Vector | Risk Level | Attack Surface | Mitigation Controls | Verification Test |
| :--- | :--- | :--- | :--- | :--- |
| **SQL Injection** | Critical | Dynamic JPA/Hibernate queries | Strict parameterized queries, Spring Data JPA Query methods, Hibernate Criteria Builder. Zero raw string concatenation. | `SqlInjectionVulnerabilityScanTest` |
| **Grade Modification Race Condition** | High | Teacher Grading REST APIs | Database-level optimistic locking via `@Version` columns on `Grade` and `AssignmentSubmission` entities. | `ConcurrentGradingConflictTest` |
| **Payment Amount Tampering** | Critical | Stripe/PayPal Checkout API | Zero client-side pricing reliance. Price lookup occurs strictly server-side; webhooks verified via HMAC-SHA256 signature. | `PaymentSignatureVerificationTest` |
| **Malicious File Upload Execution** | Critical | S3 Assignment & Document Upload | File extension whitelist (`.pdf`, `.zip`, `.doc`), MIME-type header inspection, sandboxed storage keys, no local server execution. | `FileUploadSecurityValidationTest` |

### 2.3 Repudiation
| Threat Vector | Risk Level | Attack Surface | Mitigation Controls | Verification Test |
| :--- | :--- | :--- | :--- | :--- |
| **Grade Modification Denial** | Medium | Gradebook & Assessment Service | Immutable `grade_history` audit table recording timestamp, previous score, new score, actor ID, and rationale. | `GradeAuditLogTest` |
| **Certificate Forgery Claim** | Medium | Certificate Verification Service | SHA-256 cryptographic verification codes mapped directly to immutable database issue records. | `CertificateVerificationTest` |
| **Administrative Privilege Misuse** | High | Platform Admin Dashboard | Centralized `AuditLog` entity recording IP address, user agent, actor email, target entity, and timestamp. | `AdminActionAuditLoggingTest` |

### 2.4 Information Disclosure
| Threat Vector | Risk Level | Attack Surface | Mitigation Controls | Verification Test |
| :--- | :--- | :--- | :--- | :--- |
| **Cross-Tenant Data Leakage** | Critical | Multi-Tenant Course & Progress Queries | Mandatory `organization_id` foreign key filters, `TenantContext` ThreadLocal interceptor, automatic Hibernate filters. | `CrossTenantDataIsolationTest` |
| **RAG Vector Store Exfiltration** | Critical | AI Tutor RAG Semantic Search | Permission verification *before* vector search execution; search strictly scoped by `course_id` and student enrollment. | `RAGSecurityIsolationTest` |
| **Stack Trace & Secret Exposure** | Medium | Exception Handlers | Unified `GlobalExceptionHandler` returning sanitized `ErrorResponse` DTOs with UUID `requestId` and zero stack traces. | `GlobalExceptionHandlerSecurityTest` |

### 2.5 Denial of Service
| Threat Vector | Risk Level | Attack Surface | Mitigation Controls | Verification Test |
| :--- | :--- | :--- | :--- | :--- |
| **AI LLM Cost Exhaustion Attack** | High | AI Tutor Chat Endpoint | Per-user rate limiting, per-tenant monthly token budget limits, max completion token bounds (1024 tokens). | `AiUsageMeteringTest` |
| **Database Connection Pool Exhaustion** | High | High-Concurrency Quiz Submissions | HikariCP connection pool tuning, asynchronous event publishing, non-blocking Redis caching for read-heavy routes. | `ConnectionPoolLoadTest` |

### 2.6 Elevation of Privilege
| Threat Vector | Risk Level | Attack Surface | Mitigation Controls | Verification Test |
| :--- | :--- | :--- | :--- | :--- |
| **IDOR Course Content Access** | High | `/api/v1/courses/{id}/content` | Spring Method Security `@PreAuthorize("hasAuthority('course:read')")` and server-side enrollment check. | `IdorCourseAccessTest` |
| **Student Grading Privilege Escalation** | Critical | `/api/v1/grading/*` | Strict role validation ensuring only `TEACHER`, `TEACHING_ASSISTANT`, or `PLATFORM_ADMIN` can submit grades. | `RoleElevationSecurityTest` |
